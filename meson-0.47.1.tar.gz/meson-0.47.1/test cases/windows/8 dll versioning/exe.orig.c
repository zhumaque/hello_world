int myFunc (void);

int
main (int argc, char *argv[])
{
  if (myFunc() == 55)
    return 0;
  return 1;
}
