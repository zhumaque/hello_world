int somedllfunc() {
    return 42;
}
