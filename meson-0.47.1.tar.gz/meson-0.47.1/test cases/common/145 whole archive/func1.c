#define BUILDING_DLL

#include<mylib.h>

int func1() {
    return 42;
}
