#include<subdefs.h>

int main(int argc, char **argv) {
    return subfunc() == 42 ? 0 : 1;
}
