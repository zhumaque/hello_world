#pragma once

int func1();
int func2();
int func3();
int func4();
