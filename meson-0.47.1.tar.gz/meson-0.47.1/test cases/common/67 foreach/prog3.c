#include<stdio.h>

int main(int argc, char **argv) {
    printf("This is test #3.\n");
    return 0;
}
