static int hidden_func() {
    return 0;
}
