#ifndef SAMPLE_H
#define SAMPLE_H

int wackiness();

#endif
