int number_returner();

int main(int argc, char **argv) {
    return number_returner() == 100 ? 0 : 1;
}
