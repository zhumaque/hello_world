#pragma once

void proj1_func1();
void proj1_func2();
void proj1_func3();
