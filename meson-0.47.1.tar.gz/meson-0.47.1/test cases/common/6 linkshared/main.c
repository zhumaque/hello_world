#if defined _WIN32 || defined __CYGWIN__
  #define DLL_IMPORT __declspec(dllimport)
#else
  #define DLL_IMPORT
#endif

int DLL_IMPORT func();

int main(int argc, char **arg) {
    return func();
}
