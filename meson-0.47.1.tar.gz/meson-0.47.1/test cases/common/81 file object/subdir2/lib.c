int func() {
    return 2;
}
