int func() {
    return 1;
}
