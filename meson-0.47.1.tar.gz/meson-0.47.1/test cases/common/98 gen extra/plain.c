int bob_mcbob();

int main(int argc, char **argv) {
    return bob_mcbob();
}
